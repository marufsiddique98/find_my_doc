abstract final class DateFormatUtils {
  static const String dMonthY = "d MMMM y";
  static const String monthY = "MMMM y";
  static const String monthName = "MMMM";
  static const String yearNumber = "y";
}
