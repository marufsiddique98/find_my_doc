import 'package:flutter_riverpod/flutter_riverpod.dart';

final acceptProvider = StateProvider<bool>((ref) => false);
