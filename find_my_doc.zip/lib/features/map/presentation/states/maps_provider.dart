import 'package:flutter_riverpod/flutter_riverpod.dart';

final saveAddressProvider = StateProvider.autoDispose<bool>((ref) => true);
